--[[
    Paste these entries inside the table returned by
    ox_inventory/data/items.lua (anywhere between the outer `return { ... }`
    braces is fine).

    Copy every PNG from dw-beekeeping/install/images into
    ox_inventory/web/images before starting the resource.

    The default configuration also uses an item named `sugar` for feeding
    damaged colonies. Make sure that item already exists in your items file,
    or change Config.Items.feed in config.lua to an item your server uses.
]]

['beehive'] = {
    label = 'Beehive Box',
    weight = 3000,
    stack = true,
    close = true,
    client = {
        image = 'bee-hive.png',
        event = 'beekeeping:client:useBeehive',
    },
    description = 'A wooden hive box. Find a good outdoor spot to set it up and start a colony.',
},

['queen_bee'] = {
    label = 'Queen Bee',
    weight = 50,
    stack = true,
    close = true,
    client = {
        image = 'bee-queen.png',
    },
    description = 'A live queen bee in a small travel cage. Introduce her to an empty hive to start a colony.',
},

['bee_smoker'] = {
    label = 'Bee Smoker',
    weight = 700,
    stack = false,
    close = true,
    client = {
        image = 'bee-smoker.png',
    },
    description = 'Calms bees with smoke, making stings far less likely while you work a hive. Just carry it with you.',
},

['bee_worker'] = {
    label = 'Bee Capture Jar',
    weight = 150,
    stack = true,
    close = true,
    client = {
        image = 'bee-worker.png',
        event = 'beekeeping:client:useBeeWorker',
    },
    description = 'An empty jar for luring and catching a queen from a wild swarm.',
},

['bee_wax'] = {
    label = 'Beeswax',
    weight = 250,
    stack = true,
    close = true,
    client = {
        image = 'bee-wax.png',
    },
    description = 'Raw beeswax, rendered from honeycomb at an extractor.',
},

['honey'] = {
    label = 'Honey',
    weight = 500,
    stack = true,
    close = true,
    client = {
        image = 'honey.png',
        usetime = 2500,
        status = { hunger = 150000, thirst = 50000 },
    },
    description = 'A jar of bottled honey.',
},

['alamo_honey'] = {
    label = 'Alamo Sea Honey',
    weight = 500,
    stack = true,
    close = true,
    client = {
        image = 'alamo-honey.png',
        usetime = 2500,
        status = { hunger = 150000, thirst = 50000 },
    },
    description = 'Raw honeycomb harvested from a hive near the Alamo Sea. Distinct, salty-sweet edge.',
},

['chiliad_honey'] = {
    label = 'Chiliad Wildflower Honey',
    weight = 500,
    stack = true,
    close = true,
    client = {
        image = 'chiliad-honey.png',
        usetime = 2500,
        status = { hunger = 150000, thirst = 50000 },
    },
    description = 'Raw honeycomb harvested from a hive high on Mount Chiliad.',
},

['greenhills_honey'] = {
    label = 'Grapeseed Green Hills Honey',
    weight = 500,
    stack = true,
    close = true,
    client = {
        image = 'green-hills-honey.png',
        usetime = 2500,
        status = { hunger = 150000, thirst = 50000 },
    },
    description = 'Raw honeycomb harvested from a hive on the farmland outside Grapeseed.',
},
