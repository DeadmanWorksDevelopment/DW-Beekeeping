CREATE TABLE IF NOT EXISTS `bee_hives` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `citizenid` VARCHAR(50) NOT NULL,
  `x` FLOAT NOT NULL,
  `y` FLOAT NOT NULL,
  `z` FLOAT NOT NULL,
  `w` FLOAT NOT NULL DEFAULT 0,
  `zone` VARCHAR(50) DEFAULT NULL,
  `state` ENUM('empty','colonized') NOT NULL DEFAULT 'empty',
  `tier` INT NOT NULL DEFAULT 1,
  `harvests` INT NOT NULL DEFAULT 0,
  `health` INT NOT NULL DEFAULT 100,
  `aggression` INT NOT NULL DEFAULT 0,
  `mature_at` INT DEFAULT NULL,
  `last_harvest` INT DEFAULT NULL,
  `last_fed` INT DEFAULT NULL,
  `empty_since` INT DEFAULT NULL,
  `structure` INT NOT NULL DEFAULT 100,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `citizenid` (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- If you already ran this file before `empty_since` and/or `structure`
-- existed, run whichever of these you're missing to upgrade in place
-- instead of dropping the table:
-- ALTER TABLE `bee_hives` ADD COLUMN `empty_since` INT DEFAULT NULL;
-- ALTER TABLE `bee_hives` ADD COLUMN `structure` INT NOT NULL DEFAULT 100;


