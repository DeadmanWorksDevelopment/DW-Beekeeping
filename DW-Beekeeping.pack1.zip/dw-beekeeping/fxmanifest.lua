fx_version 'cerulean'
game 'gta5'

name 'dw-beekeeping'
author 'Deadman Works Development'
description 'DW-Beekeeping | Persistent Player-Owned Beekeeping Economy | QBCore & ESX'
version '1.1.0'

lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

dependencies {
    'ox_lib',
    'ox_target',
    'ox_inventory',
    'oxmysql'
}

-- These files remain accessible to customers after Cfx.re Asset Escrow encryption.
escrow_ignore {
    'config.lua',
    'install/ox_inventory_items.lua'
}

dependency '/assetpacks'