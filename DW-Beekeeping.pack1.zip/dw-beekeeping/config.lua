Config = {}

Config.Debug = false

-- 'auto', 'qb', or 'esx'. Auto detects qb-core or es_extended at startup.
Config.Framework = 'auto'
Config.MoneyAccount = 'cash' -- QBCore: cash/bank | ESX: cash/money/bank

-- ═══════════════════════════════════════════════════════════════
--  ITEMS
--  These must exist in ox_inventory/data/items.lua
--  (see install/ox_inventory_items.lua for ready-made entries)
-- ═══════════════════════════════════════════════════════════════
Config.Items = {
    hive          = 'beehive',        -- placeable hive box
    queen         = 'queen_bee',      -- used to start a colony in an empty hive
    smoker        = 'bee_smoker',     -- carried tool, lowers sting chance while harvesting
    captureJar    = 'bee_worker',     -- used at wild swarms to try to catch a free queen
    wax           = 'bee_wax',        -- byproduct of extracting raw regional honey
    feed          = 'sugar',          -- fed to a hive to restore its health
    honey         = 'honey',          -- bottled/processed honey (final sellable product)
}

-- Raw honey harvested straight out of a hive depends on which region the
-- hive is sitting in. Outside of a defined zone, hives simply produce
-- bottled 'honey' directly. Inside a zone, hives produce the raw regional
-- item below, which is worth more raw, or can be run through the extractor
-- to turn it into 'honey' + a chance of 'bee_wax'.
Config.Zones = {
    {
        id = 'alamo_sea',
        label = 'Alamo Sea',
        coords = vec3(920.0, 3100.0, 5.5),  -- TODO verify in-game, see /beehive:coords
        radius = 300.0,
        rawHoney = 'alamo_honey',
        rawSellPrice = 55,
    },
    {
        id = 'mount_chiliad',
        label = 'Mount Chiliad',
        coords = vec3(-97.0, 5216.0, 199.5), -- TODO verify in-game, see /beehive:coords
        radius = 1000.0,
        rawHoney = 'chiliad_honey',
        rawSellPrice = 65,
    },
    {
        id = 'grapeseed',
        label = 'Grapeseed Farmland',
        coords = vec3(2440.0, 4400.0, 39.0), -- TODO verify in-game, see /beehive:coords
        radius = 350.0,
        rawHoney = 'greenhills_honey',
        rawSellPrice = 60,
    },
}

-- ═══════════════════════════════════════════════════════════════
--  PLACEMENT RULES
-- ═══════════════════════════════════════════════════════════════
Config.MaxHivesPerPlayer     = 3        -- hives a single character identifier can own at once
Config.MinDistanceFromHives  = 15.0     -- meters, checked against every hive (any owner)
Config.MinDistanceFromZoneCenter = nil  -- optional: nil disables, or set a number to force placement inside a zone's radius
Config.MaxPlacementDistance  = 3.0      -- how close you must be, looking roughly at the ground, to place
Config.GroundCheckRayLength  = 5.0

-- Hives can never be placed inside these circles - use this to keep hives
-- out of PD, hospitals, spawn points, your custom MLOs, banks, etc.
-- Add as many as you like. `label` is optional, just shown in the rejection
-- message if you set one.
Config.BlockedZones = {
    -- { coords = vec3(441.4, -982.0, 30.7), radius = 100.0, label = 'Mission Row PD' },
    -- { coords = vec3(-448.7, 6008.4, 31.7), radius = 80.0, label = 'Paleto Bay PD' },
    -- { coords = vec3(298.6, -584.7, 43.2), radius = 60.0, label = 'Pillbox Hospital' },
}

-- ═══════════════════════════════════════════════════════════════
--  HIVE LIFECYCLE
-- ═══════════════════════════════════════════════════════════════
Config.MatureMinutes     = 60     -- how long after adding a queen before the hive can be harvested
Config.RegenMinutesPerUnit = 6    -- minutes to regenerate 1 unit of honey once mature
Config.AbandonAfterHours = 72     -- colonized hive dies/is removed if never harvested for this long once mature
Config.AbandonEmptyAfterHours = 24 -- a placed hive that never gets a queen (or whose colony collapsed) is removed after this long empty
Config.MaxHealth         = 100
Config.MaxAggression     = 100

-- Hive tiers - bigger honey capacity per level, based on lifetime successful
-- harvests. These use real, verified base-game GTA V props (crate/box
-- piles) so they work out of the box with zero extra streaming - no addon
-- pack required. If you ever get dedicated hive props, just swap the model
-- here and it's picked up automatically (with the same safety checks).
Config.Tiers = {
    { level = 1, harvestsNeeded = 0,  model = `prop_crate_04a`,     capacity = 5  }, -- single crate: starter hive
    { level = 2, harvestsNeeded = 100,  model = `prop_boxpile_04a`,   capacity = 8  }, -- small stack: established hive
    { level = 3, harvestsNeeded = 500, model = `prop_cratepile_03a`, capacity = 12 }, -- big stack: thriving apiary
}

-- Marker shown for hives that don't have a valid/streamed prop model.
Config.HiveMarker = {
    type = 1,                 -- vertical cylinder, the standard "something is here" ground marker
    scale = vector3(0.6, 0.6, 0.6),
    color = { r = 250, g = 200, b = 40, a = 140 },
    drawDistance = 20.0,
}

-- ═══════════════════════════════════════════════════════════════
--  HARVESTING / RISK
-- ═══════════════════════════════════════════════════════════════
Config.HarvestSkillCheck = {
    { areaSize = 60, speedMultiplier = 1 },
    { areaSize = 50, speedMultiplier = 1.1 },
    { areaSize = 40, speedMultiplier = 1.2 },
}
Config.HarvestSkillCheckKeys = { 'w', 'a', 's', 'd' }

Config.HarvestDuration       = 8000  -- ms, progress bar length while working a hive

-- Sting chance (0-100) based on whether you're carrying a smoker and
-- whether you passed the skill check.
Config.StingChance = {
    smokerAndSuccess    = 3,
    smokerAndFail       = 20,
    noSmokerAndSuccess  = 25,
    noSmokerAndFail     = 55,
}
Config.StingDamage       = 8   -- health removed per sting event (can trigger multiple times)
Config.StingCount        = { min = 1, max = 3 }
Config.AggressionPerBadHarvest = 12  -- aggression gained when you get stung
Config.AggressionDecayPerHour  = 8   -- passive aggression decay while left alone
Config.HealthLossPerBadHarvest = 6   -- hive health lost when harvested carelessly
Config.HealthPerFeed           = 25  -- health restored per feeding
Config.FeedCooldownMinutes     = 30

-- ═══════════════════════════════════════════════════════════════
--  ECONOMY
-- ═══════════════════════════════════════════════════════════════
Config.SellPrices = {
    honey             = 35,
    bee_wax           = 20,
    alamo_honey       = 55,
    chiliad_honey     = 65,
    greenhills_honey  = 60,
}

Config.VendorItems = {
    { item = Config.Items.hive,       price = 450,  label = 'Beehive Box' },
    { item = Config.Items.queen,      price = 250,  label = 'Queen Bee' },
    { item = Config.Items.smoker,     price = 180,  label = 'Bee Smoker' },
    { item = Config.Items.captureJar, price = 60,   label = 'Bee Capture Jar' },
}

-- Extractor: converts raw regional honey -> bottled honey (+ chance of wax)
Config.ExtractYield = {
    honeyPerRaw   = 1,     -- honey items produced per raw regional honey consumed
    waxChance     = 40,    -- percent chance per raw item processed
    duration      = 6000,  -- ms
}

-- ═══════════════════════════════════════════════════════════════
--  STEALING FROM OTHER PLAYERS' HIVES
-- ═══════════════════════════════════════════════════════════════
Config.StealHoneySkillCheck = {
    { areaSize = 50, speedMultiplier = 1.1 },
    { areaSize = 40, speedMultiplier = 1.2 },
    { areaSize = 30, speedMultiplier = 1.3 },
}
Config.StealQueenSkillCheck = {
    { areaSize = 40, speedMultiplier = 1.2 },
    { areaSize = 30, speedMultiplier = 1.3 },
    { areaSize = 20, speedMultiplier = 1.4 },
}
Config.StealSkillCheckKeys = { 'w', 'a', 's', 'd' }

Config.StealHoneyDuration = 6000
Config.StealQueenDuration = 10000  -- longer than honey - stealing the queen is the bigger crime

-- Stealing is riskier than harvesting your own hive: base sting chance below,
-- PLUS a bonus scaled by the hive's current aggression, PLUS a flat bump
-- just for going after the queen specifically.
Config.StealStingChance = {
    smokerAndSuccess    = 10,
    smokerAndFail       = 35,
    noSmokerAndSuccess  = 30,
    noSmokerAndFail     = 65,
}
Config.StealAggressionStingBonus = 0.4  -- extra sting% per point of hive aggression (0-100)
Config.StealQueenExtraStingFlat  = 15

Config.TheftHealthLossHoney       = 4
Config.TheftAggressionGainHoney   = 15
Config.TheftAggressionGainQueenFail = 20

Config.StealQueenSuccessChance      = 55  -- percent, rolled only after passing the skill check
Config.StealQueenFailCooldownMinutes = 10 -- lockout on THIS hive after a failed queen theft attempt

-- Ping the hive owner (if they're online) when someone messes with their hive
Config.AlertOwnerOnTheft  = false
Config.AlertNotifyDuration = 12000 -- ms the notification itself stays on screen

-- ═══════════════════════════════════════════════════════════════
--  MOVING A HIVE (owner only)
-- ═══════════════════════════════════════════════════════════════
Config.MoveMaxDistanceFromOld = 3.0 -- how close you must be to the CURRENT spot to pick it up

-- ═══════════════════════════════════════════════════════════════
--  DESTROYING A HIVE BY DAMAGING IT (e.g. shooting it)
-- ═══════════════════════════════════════════════════════════════
Config.HiveMaxStructure   = 100  -- separate from colony health - this is the physical box's integrity
Config.ShootDamageMin     = 10
Config.ShootDamageMax     = 25
Config.ShootScanIntervalMs = 250  -- how often clients near a hive check if it just got shot
Config.ShootReportCooldownMs = 500 -- server-side: ignore duplicate reports of the same hit from multiple nearby clients

-- ═══════════════════════════════════════════════════════════════
--  WORLD LOCATIONS  (adjust these to your server/map)
--  Run `/beehive:coords` while standing on a spot to copy a ready-to-paste
--  vector4 to your clipboard.
-- ═══════════════════════════════════════════════════════════════
Config.Vendor = {
    coords = vec4(467.88, 5557.29, 292.56, 261.19),
    label = 'Beekeeping Supplies',
    ped = `a_m_m_farmer_01`,       -- real base-game ped, set to nil for no NPC (falls back to an invisible target zone)
    scenario = 'WORLD_HUMAN_STAND_IMPATIENT',
}

Config.SellPoint = {
    coords = vec4(468.68, 5559.78, 292.56, 242.08),
    label = 'Honey Buyer',
    ped = `a_m_m_hillbilly_01`,
    scenario = 'WORLD_HUMAN_STAND_IMPATIENT',
}

Config.Extractor = {
    coords = vec4(1955.0, 3735.0, 32.34, 30.0),
    label = 'Honey Extractor',
    prop = `prop_barrel_01a`, -- real base-game prop, swap for anything else you like
}

-- Static wild swarms players can try to capture a free queen from
Config.WildSwarms = {
    { id = 'swarm_sandy',    coords = vec3(1840.0, 3600.0, 34.0), cooldownMinutes = 25 },
    { id = 'swarm_grapeseed', coords = vec3(2380.0, 4350.0, 40.0), cooldownMinutes = 25 },
    { id = 'swarm_chiliad',   coords = vec3(120.0, 5100.0, 130.0), cooldownMinutes = 25 },
}

Config.CaptureChance = 45 -- percent chance of a successful capture on a passed skill check
Config.CaptureStingChanceOnFail = 30

-- ═══════════════════════════════════════════════════════════════
--  STREAMING
--  Hives are rendered client-side (not networked objects) based on data
--  synced from the server. This is how far around the player they load in.
-- ═══════════════════════════════════════════════════════════════
Config.StreamRadius = 100.0
Config.StreamCheckInterval = 1500 -- ms
