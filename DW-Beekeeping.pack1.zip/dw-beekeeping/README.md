```text
██████╗ ███████╗ █████╗ ██████╗ ███╗   ███╗ █████╗ ███╗   ██╗
██╔══██╗██╔════╝██╔══██╗██╔══██╗████╗ ████║██╔══██╗████╗  ██║
██║  ██║█████╗  ███████║██║  ██║██╔████╔██║███████║██╔██╗ ██║
██║  ██║██╔══╝  ██╔══██║██║  ██║██║╚██╔╝██║██╔══██║██║╚██╗██║
██████╔╝███████╗██║  ██║██████╔╝██║ ╚═╝ ██║██║  ██║██║ ╚████║
╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝
             W O R K S   D E V E L O P M E N T
```

# DW-Beekeeping

A persistent player-owned beekeeping, harvesting, processing, and honey economy system for FiveM QBCore and ESX servers.

## Supported Systems

- Framework: QBCore or ESX Legacy
- Inventory: ox_inventory
- Target: ox_target
- Interface and skill checks: ox_lib
- Database: oxmysql with MariaDB or MySQL

DW-Beekeeping automatically detects a running QBCore or ESX framework. You can also select the framework manually in `config.lua`.

## Required Dependencies

Install and start these resources before `dw-beekeeping`:

- One framework: `qb-core` or `es_extended`
- `ox_lib`
- `ox_target`
- `ox_inventory`
- `oxmysql`

## Installation

1. Extract the download and place the `dw-beekeeping` folder inside your server's resources directory. Do not rename the resource.
2. Import `install/install.sql` into the database used by your FiveM server.
3. Open `install/ox_inventory_items.lua` and copy its item entries inside the table returned by `ox_inventory/data/items.lua`.
4. Copy every PNG from `install/images` into `ox_inventory/web/images`.
5. Confirm that an item named `sugar` exists in ox_inventory. The default configuration uses sugar to feed damaged colonies. You may instead change `Config.Items.feed` in `config.lua`.
6. Review `config.lua`, especially all vendor, buyer, extractor, regional zone, and wild-swarm coordinates.
7. Add the resource after your framework and its dependencies in `server.cfg`.

   QBCore example:

   ```cfg
   ensure oxmysql
   ensure ox_lib
   ensure qb-core
   ensure ox_target
   ensure ox_inventory
   ensure dw-beekeeping
   ```

   ESX example:

   ```cfg
   ensure oxmysql
   ensure ox_lib
   ensure es_extended
   ensure ox_target
   ensure ox_inventory
   ensure dw-beekeeping
   ```

8. Restart the server and confirm there are no missing item, dependency, or database errors.

## Quick Coordinate Tool

Stand at the desired location and use:

```text
/beehive:coords
```

The command displays and copies a ready-to-use `vector4` value for `config.lua`.

Check these configurable locations before opening the server:

- Beekeeping supply vendor
- Honey buyer
- Honey extractor
- Alamo Sea production region
- Mount Chiliad production region
- Grapeseed production region
- Wild swarm capture locations
- Optional blocked placement zones

## Included Gameplay

### Player-Owned Hives

Players can buy a hive box and queen, place the hive outdoors, introduce the queen, and operate a persistent colony. Hive ownership and condition are stored in the database and restored after restarts.

### Hive Maturation and Honey Production

Colonies require a configurable maturation period before their first harvest. Mature hives regenerate honey over time up to the capacity allowed by their tier.

### Tier Progression

Successful harvests advance hives through configurable tiers. Higher tiers can use different props and store more honey. There is no hardcoded tier limit.

The default package uses verified base-game GTA V props, so no custom prop pack is required.

### Harvesting and Bee Stings

Harvesting uses ox_lib skill checks and progress bars. Carrying a smoker and passing the skill check reduces the chance of being stung. Poor harvesting can damage colony health and increase aggression.

### Colony Health and Feeding

Owners can feed struggling colonies with the configured feed item. Feeding restores health and uses a configurable cooldown.

### Regional Honey

Hives placed inside configured regions produce unique honey types:

- Alamo Sea Honey
- Chiliad Wildflower Honey
- Grapeseed Green Hills Honey

Hives outside a regional zone produce standard honey.

### Honey Extraction

Regional raw honey can be processed at the extractor into bottled honey, with a configurable chance of producing beeswax as a byproduct.

### Vendor and Honey Buyer

The resource includes configurable vendor and buyer NPCs using base-game ped models. Players purchase supplies and sell supported honey products and beeswax using the configured QBCore or ESX money account.

### Wild Queen Capture

Players can use a Bee Capture Jar at configured wild swarm locations for a chance to capture a queen. Captures use skill checks, success chances, sting risks, and per-location cooldowns.

### Hive Relocation

Owners can move an existing hive through the ox_target menu. A transparent preview follows the player until the new placement is confirmed. The relocated hive keeps its tier, colony, health, aggression, and stored honey.

### Hive Theft

Other players can attempt to steal honey or the queen from a colonized hive. Theft includes harder skill checks, increased sting risk, hive stress, failure cooldowns, and optional owner notifications.

Successfully stealing a queen gives the thief a queen item and collapses the affected colony.

### Physical Hive Damage

Hives have a separate configurable structure value. Real hive props can be damaged by gunfire and permanently destroyed. Owners can receive damage and destruction alerts.

### Inactivity Cleanup

The maintenance system automatically removes abandoned colonized hives and empty hives after configurable periods. This prevents unused hives from permanently consuming player placement slots.

### Privacy and No Hive Blips

Hives do not create map or radar blips. Public clients receive only the data required to render and interact with hives; private ownership information is sent separately to the owner.

### Server-Side Validation

Important actions are revalidated by the server, including player distance, ownership, inventory items, placement limits, placement spacing, cooldowns, and transaction amounts.

## Configuration Highlights

Customers can configure:

- Maximum hives per player
- Framework auto-detection or manual QBCore/ESX selection
- Cash or bank account selection
- Minimum distance between hives
- Maximum placement distance
- Blocked placement zones
- Colony maturation time
- Honey regeneration rate
- Empty and colonized hive cleanup periods
- Hive health and aggression
- Unlimited custom tier definitions
- Tier props and storage capacities
- Harvest skill checks and keys
- Smoker and non-smoker sting chances
- Sting damage and sting count
- Feeding amount and cooldown
- Vendor stock and prices
- Honey and beeswax sale prices
- Regional honey zones
- Extraction yield and wax chance
- Theft skill checks and success chances
- Owner theft alerts
- Hive structure and gunfire damage
- Vendor, buyer, and extractor locations
- Wild swarm locations and cooldowns
- Streaming radius and update interval

## Included Inventory Items

Ready-to-paste ox_inventory entries and matching transparent PNG images are included for:

- Beehive Box
- Queen Bee
- Bee Smoker
- Bee Capture Jar
- Beeswax
- Honey
- Alamo Sea Honey
- Chiliad Wildflower Honey
- Grapeseed Green Hills Honey

## Commands

| Command | Access | Purpose |
|---|---|---|
| `/beehive:coords` | Everyone | Displays and copies the player's current coordinates for configuration. |
| `/beehive:remove <id>` | Framework admin or ACE `beekeeping.admin` | Permanently removes a hive by database ID. |

QBCore `admin`/`god` and ESX `admin`/`superadmin` groups are recognized automatically. You can also grant the cross-framework ACE permission:

```cfg
add_ace group.admin beekeeping.admin allow
```

## Customer-Editable Files

These Lua files remain open when delivered through Cfx.re Asset Escrow:

- `config.lua` — gameplay, economy, items, locations, limits, tiers, and balancing
- `install/ox_inventory_items.lua` — ready-to-paste inventory entries

The SQL file, images, README, and license also remain available to customers.

## First-Start Checklist

- One supported framework and all four shared dependencies start before `dw-beekeeping`.
- `install/install.sql` was imported into the active database.
- All item entries were added inside the ox_inventory items table.
- All nine PNG files were copied into `ox_inventory/web/images`.
- The configured feed item exists.
- Vendor, buyer, extractor, zones, and wild swarm coordinates were tested.
- A player can buy supplies, place a hive, add a queen, inspect it, and move it.
- Harvesting, selling, extraction, theft, damage, and restart persistence were tested on a staging server.

## Troubleshooting

**The resource reports a missing dependency**  
Confirm the resource names match exactly and correct the order in `server.cfg`.

**An inventory item has no image**  
Copy the matching PNG from `install/images` into `ox_inventory/web/images`, then restart ox_inventory or the server.

**A hive cannot be placed**  
Check the server console for the exact validation or database error. Confirm the player is outdoors, within the placement distance, outside blocked zones, below the hive limit, and far enough from other hives.

**A configured prop does not appear**  
Use a valid base-game or properly streamed model. Invalid models fall back to a visible ground marker and produce an F8 warning.

**NPCs or interaction points are in the wrong location**  
Use `/beehive:coords` and replace the appropriate coordinates in `config.lua`.

## Support

For product support, bug reports, and update information, join Deadman Works Development:

https://discord.gg/tJ9EkS24Eq

When requesting support, include the resource version, framework and version, ox_inventory version, relevant console error, and steps needed to reproduce the issue.

---

Copyright © 2026 Deadman Works Development. All rights reserved.  
Use of this resource is governed by the included `LICENSE` file.
